package com.limonchik.escooter

object Config {
    const val APP_NAME: String = "E-scooter App"
    const val VERSION: String = "1.05"
    const val AUTHOR: String = "limonchik"

    /** Главный выключатель записи. false = все кадры только в журнал (TX-DRY), в BLE ничего не уходит. */
    const val ALLOW_WRITE: Boolean = true

    /** Передачи, скорости, круиз, режим старта, мили, пешеходный режим. Дополнительно требуют «Расширенное управление» в настройках. */
    const val ALLOW_SPEED_MODES: Boolean = true

    /** Сброс настроек контроллера. Выключено в сборке. */
    const val ALLOW_DANGEROUS: Boolean = false

    /** Жёсткий потолок скорости передачи, км/ч (дополнительно ограничен диапазоном контроллера из AA 57). */
    const val MAX_SPEED_KMH: Int = 50

    /** Оригинал шлёт кадр скорости 3 раза подряд (цикл i<3 в SpeedSettingActivity). */
    const val SPEED_FRAME_REPEAT: Int = 3

    /** Протокол прошивки в оригинальном приложении не найден. */
    const val FIRMWARE_PROTOCOL_KNOWN: Boolean = false
}
