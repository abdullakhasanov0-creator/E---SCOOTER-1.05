package com.limonchik.escooter

/**
 * Точка расширения для прошивки. В KCQ Scooter 1.5.4 нет ни одной команды прошивки (OTA/DFU):
 * проверено по строкам и классам classes.dex. Пока формат пакетов неизвестен, прошивать нечем.
 */
interface FirmwareFlasher {
    val available: Boolean
    val reason: String
}

object NoFlasher : FirmwareFlasher {
    override val available: Boolean = Config.FIRMWARE_PROTOCOL_KNOWN
    override val reason: String =
        "В оригинальном приложении KCQ Scooter 1.5.4 нет команд прошивки. Формат пакетов обновления неизвестен, " +
            "поэтому запись прошивки в контроллер отключена. Выдуманные байты могут вывести контроллер из строя."
}

/** Профиль скоростей трёх передач, км/ч. Это не прошивка: значения пишутся штатными кадрами A7/A8. */
data class SpeedProfile(val name: String, val g1: Int, val g2: Int, val g3: Int) {
    val max: Int get() = maxOf(g1, g2, g3)
}

object SpeedProfiles {
    val STANDARD = SpeedProfile("до 25 км/ч", 15, 20, 25)
    val MAX50 = SpeedProfile("до 50 км/ч", 25, 35, 50)
    val all = listOf(STANDARD, MAX50)
}
