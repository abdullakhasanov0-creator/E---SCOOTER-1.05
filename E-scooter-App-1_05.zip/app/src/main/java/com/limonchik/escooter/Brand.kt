package com.limonchik.escooter

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Семейство самоката. Полное управление есть только у Kugoo/KCQ; у остальных протоколы закрыты авторизацией. */
enum class Brand(val title: String, val controllable: Boolean, val about: String, val features: List<String>) {
    KUGOO(
        "Kugoo / KCQ", true,
        "Контроллеры KCQ (сервис FFF0): полное управление.",
        listOf("Скорость, передачи, режимы", "Свет, блокировка, круиз", "Диагностика и профили до 50 км/ч"),
    ),
    NINEBOT(
        "Ninebot", false,
        "Ninebot (Max G30, ES и др.): связь шифруется и требует авторизации, поэтому писать в контроллер из приложения небезопасно.",
        listOf("Поиск устройства и журнал сервисов", "Прошивки и снятие ограничений через ScooterHacking Utility"),
    ),
    XIAOMI(
        "Xiaomi", false,
        "Xiaomi / Mijia (M365, Pro и др.): новые прошивки требуют авторизации, без неё запись в контроллер не принимается.",
        listOf("Поиск устройства и журнал сервисов", "Прошивки через ScooterHacking Utility"),
    ),
}

const val FLASHER_PACKAGE = "sh.cfw.utility"

/** Экран для брендов без прямого управления: что доступно и кнопка к приложению-прошивальщику. */
@Composable
fun BrandPanel(brand: Brand, open: (Sub) -> Unit, scan: () -> Unit, say: (String) -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
        BigTitle(brand.title)
        Spacer(Modifier.height(8.dp))
        CardBox {
            Text(brand.about, color = p.sub, fontSize = 14.sp)
        }
        SectionTitle("Что доступно")
        CardBox {
            brand.features.forEach { f ->
                Text("•  $f", color = p.text, fontSize = 15.sp, modifier = Modifier.padding(vertical = 3.dp))
            }
            Spacer(Modifier.height(10.dp))
            PrimaryButton("Найти устройство") { open(Sub.CONNECT); scan() }
            Spacer(Modifier.height(8.dp))
            SecondaryButton("Прошивки: ScooterHacking Utility") {
                val i = ctx.packageManager.getLaunchIntentForPackage(FLASHER_PACKAGE)
                if (i == null) say("Приложение ScooterHacking Utility не установлено")
                else ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        Text(
            "Во многих странах выше 25 км/ч ездить на самокате по общим дорогам нельзя. Прошивка может лишить гарантии и вывести самокат из строя.",
            color = p.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp, top = 10.dp),
        )
    }
}
