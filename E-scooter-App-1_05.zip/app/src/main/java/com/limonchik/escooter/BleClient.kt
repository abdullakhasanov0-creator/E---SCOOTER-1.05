package com.limonchik.escooter

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID

object Uuids {
    private fun u16(x: Int): UUID = UUID.fromString(String.format("%08x-0000-1000-8000-00805f9b34fb", x))
    val SERVICE: UUID = u16(0xFFF0)
    val PWD_STATUS: UUID = u16(0xFFF1)
    val WRITE: UUID = u16(0xFFF6)
    val NOTIFY: UUID = u16(0xFFF7)
    val CCC: UUID = u16(0x2902)
    val DIS: UUID = u16(0x180A)
    /** Стандартные характеристики Device Information (в оригинале читается только 2A23). */
    val DIS_CHARS: List<Pair<String, UUID>> = listOf(
        "2A23 System ID" to u16(0x2A23),
        "2A24 Model" to u16(0x2A24),
        "2A25 Serial" to u16(0x2A25),
        "2A26 Firmware" to u16(0x2A26),
        "2A27 Hardware" to u16(0x2A27),
        "2A28 Software" to u16(0x2A28),
        "2A29 Manufacturer" to u16(0x2A29),
    )
}

enum class ConnState { DISCONNECTED, CONNECTING, READY }

data class Found(val address: String, val name: String?, val rssi: Int, val hasService: Boolean, val kind: String = "")

/** Грубое определение семейства по сервисам из рекламы. Управление поддерживается только для KCQ (FFF0). */
fun guessKind(uuids: List<java.util.UUID>): String {
    val s = uuids.map { it.toString().lowercase() }
    return when {
        s.any { it.startsWith("0000fff0-") } -> "KCQ"
        s.any { it.startsWith("6e400001-") } -> "Ninebot / Xiaomi (NUS)"
        s.any { it.startsWith("0000fe95-") } -> "Xiaomi"
        s.any { it.startsWith("00001910-") || it.startsWith("0000a201-") } -> "Tuya"
        else -> ""
    }
}

@SuppressLint("MissingPermission")
class BleClient(private val ctx: Context, private val l: Listener) {

    interface Listener {
        fun onScan(list: List<Found>)
        fun onScanning(on: Boolean)
        fun onConn(s: ConnState, address: String?)
        fun onRx(data: ByteArray)
        fun onInfo(name: String, data: ByteArray)
        fun onTx(data: ByteArray)
        fun onNote(text: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var gatt: BluetoothGatt? = null
    private var wChar: BluetoothGattCharacteristic? = null
    private var address: String? = null

    // ---------- очередь GATT-операций (по одной за раз) ----------
    private class Op(val name: String, val run: () -> Boolean)

    private val queue = ArrayDeque<Op>()
    private var running = false
    private var pendingName = ""
    private val opTimeout = Runnable {
        l.onNote("таймаут операции GATT")
        running = false
        pump()
    }

    private fun enqueue(name: String, run: () -> Boolean) {
        main.post {
            queue.addLast(Op(name, run))
            pump()
        }
    }

    private fun pump() {
        if (running) return
        val op = queue.removeFirstOrNull() ?: return
        running = true
        val ok = try { op.run() } catch (e: Exception) { false }
        if (ok) {
            main.postDelayed(opTimeout, 3000)
        } else {
            l.onNote("операция не запущена: ${op.name}")
            running = false
            pump()
        }
    }

    private fun done() {
        main.removeCallbacks(opTimeout)
        running = false
        pump()
    }

    // ---------- сканирование ----------
    private val found = LinkedHashMap<String, Found>()
    private val stopScanRunnable = Runnable { stopScan() }
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = try { result.scanRecord?.deviceName ?: result.device.name } catch (e: SecurityException) { null }
            val has = result.scanRecord?.serviceUuids?.any { it.uuid == Uuids.SERVICE } == true
            val kind = guessKind(result.scanRecord?.serviceUuids?.map { it.uuid } ?: emptyList())
            found[result.device.address] = Found(result.device.address, name, result.rssi, has, kind)
            val list = found.values.sortedWith(compareByDescending<Found> { it.hasService }.thenByDescending { it.rssi })
            main.post { l.onScan(list) }
        }

        override fun onScanFailed(errorCode: Int) {
            main.post {
                l.onNote("сканирование не удалось, код $errorCode")
                l.onScanning(false)
            }
        }
    }

    fun startScan() {
        val scanner = adapter?.bluetoothLeScanner
        if (adapter == null || !adapter.isEnabled || scanner == null) {
            l.onNote("Bluetooth выключен или недоступен")
            return
        }
        found.clear()
        l.onScan(emptyList())
        l.onScanning(true)
        scanner.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCb)
        main.postDelayed(stopScanRunnable, 15000)
    }

    fun stopScan() {
        main.removeCallbacks(stopScanRunnable)
        try { adapter?.bluetoothLeScanner?.stopScan(scanCb) } catch (e: Exception) { /* ignore */ }
        l.onScanning(false)
    }

    // ---------- подключение ----------
    fun connect(addr: String) {
        stopScan()
        val dev = adapter?.getRemoteDevice(addr) ?: return
        gatt?.close()
        address = addr
        l.onConn(ConnState.CONNECTING, addr)
        gatt = dev.connectGatt(ctx, false, cb, android.bluetooth.BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        val g = gatt
        if (g == null) l.onConn(ConnState.DISCONNECTED, null) else g.disconnect()
    }

    private fun cleanup(g: BluetoothGatt) {
        g.close()
        if (gatt === g) gatt = null
        queue.clear()
        running = false
        main.removeCallbacks(opTimeout)
        wChar = null
        l.onConn(ConnState.DISCONNECTED, null)
    }

    private fun setup(g: BluetoothGatt) {
        val svc = g.getService(Uuids.SERVICE)
        val wr = svc?.getCharacteristic(Uuids.WRITE)
        val nt = svc?.getCharacteristic(Uuids.NOTIFY)
        if (svc == null || wr == null || nt == null) {
            l.onNote("Нет сервиса FFF0 / характеристик FFF6, FFF7 — это не контроллер KCQ. Сервисы устройства (для журнала):")
            g.services.take(12).forEach { sv ->
                val ch = sv.characteristics.joinToString(", ") { it.uuid.toString().substring(4, 8) }
                l.onNote("  ${sv.uuid}: $ch")
            }
            disconnect()
            return
        }
        wChar = wr
        enqueue("notify FFF7") { enableNotify(g, nt) }
        if (svc.getCharacteristic(Uuids.PWD_STATUS) != null) {
            enqueue("read FFF1") { readInfo(g, "FFF1 pwd-status", Uuids.SERVICE, Uuids.PWD_STATUS) }
        }
        for ((name, id) in Uuids.DIS_CHARS) {
            if (g.getService(Uuids.DIS)?.getCharacteristic(id) != null) {
                enqueue("read $name") { readInfo(g, name, Uuids.DIS, id) }
            }
        }
        l.onConn(ConnState.READY, address)
    }

    @Suppress("DEPRECATION")
    private fun enableNotify(g: BluetoothGatt, c: BluetoothGattCharacteristic): Boolean {
        if (!g.setCharacteristicNotification(c, true)) return false
        val d = c.getDescriptor(Uuids.CCC) ?: return false
        return if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothStatusCodes.SUCCESS
        } else {
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }
    }

    private fun readInfo(g: BluetoothGatt, name: String, service: UUID, id: UUID): Boolean {
        val c = g.getService(service)?.getCharacteristic(id) ?: return false
        pendingName = name
        return g.readCharacteristic(c)
    }

    @Suppress("DEPRECATION")
    private fun doWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, v: ByteArray): Boolean =
        if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, v, c.writeType) == BluetoothStatusCodes.SUCCESS
        } else {
            c.value = v
            g.writeCharacteristic(c)
        }

    /** Повторное чтение доступных информационных характеристик (версии, серийный номер). */
    fun readAllInfo() {
        val g = gatt ?: return
        if (g.getService(Uuids.SERVICE)?.getCharacteristic(Uuids.PWD_STATUS) != null) {
            enqueue("read FFF1") { readInfo(g, "FFF1 pwd-status", Uuids.SERVICE, Uuids.PWD_STATUS) }
        }
        for ((name, id) in Uuids.DIS_CHARS) {
            if (g.getService(Uuids.DIS)?.getCharacteristic(id) != null) {
                enqueue("read $name") { readInfo(g, name, Uuids.DIS, id) }
            }
        }
    }

    /** Запись в FFF6 (тип записи — по умолчанию характеристики, как в оригинале). */
    fun write(frames: List<ByteArray>) {
        for (f in frames) {
            enqueue("write FFF6") {
                val g = gatt
                val c = wChar
                if (g == null || c == null) {
                    false
                } else {
                    val ok = doWrite(g, c, f)
                    if (ok) l.onTx(f)
                    ok
                }
            }
        }
    }

    private fun rx(v: ByteArray) {
        main.post { l.onRx(v) }
    }

    private fun readDone(v: ByteArray, status: Int) {
        main.post {
            if (status == BluetoothGatt.GATT_SUCCESS) l.onInfo(pendingName, v) else l.onNote("чтение $pendingName: status=$status")
            done()
        }
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                main.post { l.onNote("GATT подключён (status=$status), ищу сервисы") }
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                main.post {
                    l.onNote("GATT отключён (status=$status)")
                    cleanup(g)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            main.post {
                if (status == BluetoothGatt.GATT_SUCCESS) setup(g) else l.onNote("сервисы: status=$status")
            }
        }

        @Deprecated("API < 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            rx(v.copyOf())
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            rx(value.copyOf())
        }

        @Deprecated("API < 33")
        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            readDone((c.value ?: ByteArray(0)).copyOf(), status)
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            readDone(value.copyOf(), status)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            main.post {
                if (status != BluetoothGatt.GATT_SUCCESS) l.onNote("запись: status=$status")
                done()
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            main.post {
                if (status != BluetoothGatt.GATT_SUCCESS) l.onNote("включение уведомлений: status=$status")
                done()
            }
        }
    }
}
